#!/usr/bin/env python3
"""Independent matrix checks, not imports of the project's response formulas."""
from pathlib import Path
import numpy as np,json,argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checkpoint05',type=Path,required=True)
parser.add_argument('--output',type=Path,default=Path('checks'))
args=parser.parse_args()
CP=args.checkpoint05.resolve(); OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(2026090501)

def swap_qubits(n,a,b):
    p=np.zeros((2**n,2**n),complex)
    for i in range(2**n):
        bits=list(format(i,f'0{n}b'));bits[a],bits[b]=bits[b],bits[a]
        p[int(''.join(bits),2),i]=1
    return p
Fa=swap_qubits(4,0,2);Fb=swap_qubits(4,1,3)
basis=np.array([np.eye(16),Fa,Fb,Fa@Fb],complex)
gram=np.einsum('aij,bji->ab',basis,basis).real
SWAP=swap_qubits(2,0,1)
def haar():
    m=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4))
    q,r=np.linalg.qr(m);z=np.diag(r);return q*(z/abs(z))
def operator_entropy(u):
    realigned=u.reshape(2,2,2,2).transpose(0,2,1,3).reshape(4,4)
    a=realigned@realigned.conj().T
    return 1-float(np.trace(a@a).real)/16
err=[]
for _ in range(100):
    u=haar(); uu=np.kron(u,u);omega=uu.conj().T@Fa@uu
    ov=np.einsum('aij,ji->a',basis,omega).real
    coeff=np.linalg.solve(gram,ov)
    eu=operator_entropy(u);es=operator_entropy(u@SWAP)
    ep=(eu+es-.75)/.75;gt=(eu-es+.75)/1.5
    formula=np.array([2*ep/3,1-gt-5*ep/6,gt-5*ep/6,2*ep/3])
    err.append(float(np.max(abs(coeff-formula))))
# Exact full-group fresh-gate average, directly on four-qubit statevectors.
gates=np.load(CP/'data/two_qubit_clifford_group.npz')['gates']
def purity(psi,k):
    m=psi.reshape(2**k,-1);rho=m@m.conj().T;return float(np.trace(rho@rho).real)
def mean_purity(psi):
    ps=np.einsum('gij,ljr->glir',gates,psi.reshape(2,4,2)).reshape(len(gates),4,4)
    red=ps@np.swapaxes(ps.conj(),-1,-2)
    return float(np.einsum('gij,gji->g',red,red).real.mean())
bell=np.array([1,0,0,1],complex)/np.sqrt(2)
product=np.zeros(16,complex);product[0]=1
states={'product':product,'two_internal_bell_pairs':np.kron(bell,bell)}
for k in range(10):
    p=rng.normal(size=16)+1j*rng.normal(size=16);states[f'random_{k}']=p/np.linalg.norm(p)
rows=[]
for name,p in states.items():
    pl,pc,pr=purity(p,1),purity(p,2),purity(p,3)
    predicted=.4*(pl+pr);direct=mean_purity(p)
    rows.append(dict(state=name,central_purity=pc,left_purity=pl,right_purity=pr,
                     predicted_post_purity=predicted,direct_post_purity=direct,error=abs(predicted-direct),
                     direct_relative_response=(4/3)*(1-direct/pc)))
out={'invariant_formula_random_unitaries':100,'max_coefficient_error':max(err),
     'clifford_group_size':len(gates),'state_checks':rows,
     'max_clifford_purity_error':max(r['error'] for r in rows)}
(OUT/'independent_identity_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
