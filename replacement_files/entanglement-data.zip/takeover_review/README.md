# Takeover review checks

Read `TAKEOVER_REVIEW.md` first. These files record a read-only review; they are not a repository patch or manuscript package.

## Reproduce the new checks

Extract `entanglement_project_checkpoint_05.zip` into a working directory. Use Python 3.10 or later with NumPy, pandas and SciPy.

```bash
python numerical_screen.py --checkpoint05 /path/to/entanglement_project_checkpoint_05 --output checks
python independent_identity_checks.py --checkpoint05 /path/to/entanglement_project_checkpoint_05 --output checks
```

The numerical screen independently recomputes point estimates from saved raw state/intervention rows and adds explicitly post-hoc model/pairing diagnostics. It does not run the original large simulations. The independent identity check implements its own matrix contractions but uses the archived Clifford gate bank.

The included `checks/tableau_rerun.json` comes from rerunning the original archive script. To repeat it, also install Numba and run:

```bash
python /path/to/entanglement_project_checkpoint_05/scripts/validate_tableau_against_statevector.py --clifford-table /path/to/entanglement_project_checkpoint_05/data/two_qubit_clifford_group.npz --maps /path/to/entanglement_project_checkpoint_05/data/two_qubit_clifford_symplectic_maps.npz --report checks/tableau_rerun.json
```

The original archives and artwork are not duplicated in this small review bundle. No source file from the project was altered. Numerical last digits can differ with floating-point libraries.
