# Boundary Entangling Susceptibility: takeover review

**Date:** 2026-09-05  
**Remote revision inspected:** `fffe33e6f59717679a959b5a5a17ead63e6c213a`  
**Repository:** `GoGoKo699/Boundary-Entangling-Susceptibility`  
**Mode:** read-only. No repository file, accepted figure, or manuscript was modified.

## Conclusion

Retain the five-part scientific scope and the four-figure narrative. There is substantial numerical support for the fixed-spectrum response mechanism, but the previous green CI result is not a complete scientific audit. A concrete weakness is the interpretation of the fitted distance scale as an established exponential law. Figure synchronization and some previously reported repository fixes also remain incomplete.

The strongest initial result of this review is that the large-size point estimates and the paired sign reversal are recoverable from the archived state/intervention rows. The main caution concerns model interpretation and completeness of provenance, not loss of the basic numerical effect.

## What was actually checked

| Check | Fresh result | Limitation |
|---|---|---|
| Remote main revision and recorded Actions run | Inspected current head; recorded run 33030018662 is successful | This review did not trigger a new remote run |
| Two source ZIP identities | Both match the SHA-256 values in current repository DATA_POLICY | Does not by itself certify every file's contents |
| Archived primary and replication state rows | 172,800 + 64,800 rows read | Original large simulations were not rerun |
| Response formula against every stored state row | Maximum discrepancy 8.33e-17 | Checks consistency of observables with stored entropy data |
| Independent fixed-effect reconstruction | All 16 relative-response slopes reproduced; maximum discrepancy 7.92e-16 | Point estimates, not fresh complete bootstrap intervals |
| Paired endpoint reconstruction | Unconditional +0.0714074074132; conditional -0.0474290225329 | Preserves the original selection and averaging definition |
| Provided tableau/state-vector validation rerun | All 256 cases pass; both maximum errors zero | Rerun of supplied validation, not external replication |
| Newly coded matrix projection check | 100 random two-qubit gates; maximum coefficient discrepancy 1.11e-15 | Numerical test of general coefficient identity, not a proof |
| Direct full-Clifford-group probe average | 11,520 gates on 12 four-qubit inputs; maximum purity discrepancy 6.67e-16 | Uses supplied gate bank but independently coded contractions |

See `checks/summary.json`, `checks/raw_row_slope_reconstruction.csv`, `checks/tableau_rerun.json`, and `checks/independent_identity_checks.json`.

## 1. Distance model: an important interpretation issue

The archived fit is

$$f(d)=-A\exp(-d/\xi),\qquad A=0.051586755479,\quad\xi=2.37208530434.$$

The source fitting routine uses unweighted nonlinear least squares, despite different uncertainties at the six distances. It refits bootstrap draws to obtain a parameter interval, but does not report a goodness-of-fit assessment.

| Distance | Observed mean | Fitted value | Source 95% pointwise interval |
|---:|---:|---:|---|
| 0 | -0.047515 | -0.051587 | [-0.049491, -0.045575] |
| 1 | -0.043709 | -0.033842 | [-0.046288, -0.041182] |
| 2 | -0.018461 | -0.022201 | [-0.020135, -0.016864] |
| 4 | -0.005399 | -0.009554 | [-0.006291, -0.004545] |
| 8 | -0.001111 | -0.001770 | [-0.001500, -0.000759] |
| 16 | -0.000278 | -0.000061 | [-0.000500, -0.000093] |

All six fitted values are outside the corresponding pointwise intervals. At distance four the residual is about 9.37 marginal bootstrap standard deviations. This comparison is a diagnostic, not a formal six-independent-tests argument: the means are correlated and fit parameters are estimated.

A supplementary generalized least-squares fit using the covariance of the 5,000 archived bootstrap curves gives approximately A=0.0499314 and xi=2.04549, but still has a quadratic residual of 140.59 with nominal residual dimension four. No exact p-value is assigned: covariance is estimated, the fit is nonlinear, and tail observations are sparse.

**Interpretation:** short-range suppression is supported by the displayed data. A single exponential accurately describing the profile, or a precise physically identified localization length, is not established by the current fit. A narrow bootstrap interval for the fitted parameter does not account for model misspecification.

**Recommendation:** retain the raw points and the paired effect. Check cell-resolved profiles, fit residuals, distance-window sensitivity, and common-sample conditioning before deciding whether xi is only a descriptive fitted scale or should be removed from the main claim. Do not silently replace the fit, change the data, or unfreeze the accepted artwork.

## 2. The paired causal endpoint survives stricter diagnostic pairing

The source code first filters individual location interventions by `delta_S_central == 0`, averages eligible left/right locations at a distance, and then pairs near and far averages. Thus the exact estimand should say which locations are eligible and when averaging occurs. The distance curve can use different eligible pre-state/side sets at different distances.

As a new post-hoc sensitivity check, this review paired distance zero and distance n/4 on the **same side**, requiring unchanged central spectrum under **both** interventions before averaging eligible pairs within each pre-state. The equal-cell estimate is -0.0474737195865, close to the original -0.0474290225329; all nine cell means remain negative. There are 7,945 eligible side pairs from 4,786 trajectories. No new interval is claimed for this sensitivity check.

An additional common-eligibility check requires every displayed distance to preserve the spectrum on the same side/pre-state. It retains 6,008 side/pre-state combinations, representing 4,025 trajectories. Its pointwise pooled effects remain negative and decrease in magnitude. This helps separate the existence of the distance effect from changing sample composition, without treating the post-hoc curve as the frozen primary result.

## 3. Finite-size persistence and the limit must remain distinct

All sixteen relative-response coefficients were reconstructed from archived state rows using independently coded within-stratum demeaning. Their negativity is not a plotting artifact.

The locked inverse-size fit is a model, not a theorem. A simple residual screen using standard errors approximated from the stored 95% intervals gives a quadratic residual of 16.78 on nominal dimension two for the primary random-Pauli size series. The other series are recorded in `checks/size_fit_diagnostics.csv`. This is a diagnostic based on interval-derived errors, not a definitive model-selection analysis.

The present conclusion should distinguish direct finite-size evidence from the extrapolated value and its model-conditional uncertainty. The original methods also correctly state that at n=256 no one exact-spectrum stratum spans the full monitoring grid: beta is an overlap-weighted within-stratum trend, not one universally matched extreme-rate contrast.

## 4. Observable definition should remain explicit

The code and numerical methods define

$$\chi_{\mathrm{rel}}=\frac{D}{D-1}\left(1-\frac{\mathbb E_U P'_m}{P_m}\right),$$

where D is the half-chain Hilbert-space dimension. This is a purity-normalized normalized-linear-entropy response. It is not generally the finite-gate mean second-Renyi entropy increment

$$\mathbb E_U[-\log_2 P'_m]-[-\log_2 P_m].$$

The existing symbol and definition can be retained; descriptive prose should not conflate the two endpoints. D is used here only to distinguish dimension from measurement distance, not to change frozen figure labels.

## 5. A short exact example can clarify the story without another figure

On a four-qubit chain with central cut 12|34, compare |0000> with a Bell pair within 12 times a Bell pair within 34. Both have central spectrum (1,0,0,0). Their neighboring purities differ. The exact relative responses are respectively 4/15 and 4/5. Direct averaging over the supplied full two-qubit Clifford bank confirms these values.

This elementary example is an explanation of central-spectrum insufficiency, not a claim of new literature priority. The scientific contribution should emphasize the monitored-state redistribution and physical interventions rather than present insufficiency alone as the entire discovery.

## 6. Current repository gaps, not inferred from old messages

- The current Figure 1 browser SVG has a 292 by 176 viewBox and 7.2-size tick labels. The accepted PDF in the frozen archive has page dimensions 303.84 by 194.40 points and 8.6-point tick labels. The SVG matches the older pre-enlargement variant, not the accepted typography. This is not just a PDF timestamp difference.
- Current `scripts/figures/make_figure_02.py` still saves only PDF files. The earlier proposed local patch and the merged remote audit are not identical.
- Current `docs/CODE_MAP.md` still names unimplemented study directory names, tests, and provenance paths. Its blob identity is unchanged from the previously flagged stale version.
- `verify.py` has useful schema, sign, and structural tests. It does not replay the whole raw-to-estimate analysis or check the distance-model residuals. Existence of a syntactically valid SVG does not establish agreement with frozen artwork.
- `docs/DATA_POLICY.md` records valid source archive hashes but still describes immutable raw-data deposits and frozen-PDF deposits as pending.

Recommended repository behavior is one generation path for PDF/PNG/SVG, immutable accepted PDF assets kept distinct from regenerated output, and a raw-data manifest that permits selected numerical endpoints to be replayed from trajectory rows. Tests that guard frozen data should be labeled regression tests, not independent scientific validation.

## Recommended next checkpoint

One bounded evidence-and-reproducibility pass, using existing data rather than adding models or larger simulations:

1. Synchronize the accepted figure assets and document the actual source-to-output paths.
2. Resolve Figure 4 fit interpretation and state the paired conditioning rule precisely.
3. Separate finite-size observations, model-conditional extrapolations, and model sensitivity.
4. Apply only the resulting supported code/documentation corrections and verify the remote commit.

Then continue the GitHub-first narrative and dialogue report. Retain the original no-TeX/no-TikZ repository policy and the five frozen scope items. No manuscript draft or new publication-readiness verdict was produced in this review.

## Reproduction and sources

The scripts supplied with this note read an extracted original Checkpoint 05 package. They do not require a manuscript or Overleaf source.

Remote sources inspected at the revision above:

- `verify.py`
- `docs/NUMERICAL_METHODS.md`
- `docs/CODE_MAP.md`
- `docs/DATA_POLICY.md`
- `studies/checkpoint_05/scripts/analyze_measurement_location.py`
- `scripts/figures/make_figure_02.py`
- `figures/core_svg/figure_01_panel_b.svg`
- recursive Git tree and Actions run 33030018662

Source archives verified locally:

- Checkpoint 04: `690722855b37c5ba1aab96720e03d0f36e7b2b0b86447827f9eeecda0a973023`
- Checkpoint 05: `284a92bfac08af6194cd576ce07c4be90e1e760fcc7b0fc7951eaacd1fa975ce`

Not covered: a full new large-system simulation campaign, the complete Figure 1 raw-intervention reanalysis, a fresh full raw-bootstrap rerun, an external specialist audit, or an exhaustive priority search.
