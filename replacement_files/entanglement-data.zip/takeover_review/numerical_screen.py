#!/usr/bin/env python3
"""Read-only takeover checks on the supplied checkpoint archives.

These calculations independently reconstruct point estimates from stored rows.
They do not rerun the original large-scale random circuits. Extra fit and
pairing diagnostics are post-hoc checks, not replacements for locked endpoints.
"""
from pathlib import Path
import json, sys, argparse
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from scipy.linalg import cholesky, solve_triangular
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checkpoint05',type=Path,required=True,help='Extracted Checkpoint 05 directory')
parser.add_argument('--output',type=Path,default=Path('checks'))
args=parser.parse_args()
CP=args.checkpoint05.resolve()
OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=True)
report={}
# 1. Recompute exact response from entropy rows and FE slopes without importing
# any checkpoint estimator code.
slope_rows=[]
for run, folder in [('primary','primary_scaling'),('replication','independent_replication')]:
    df=pd.read_csv(CP/f'data/{folder}/stabilizer_scaling_states.csv.gz')
    dl=df.S_central-df.S_left_neighbor
    dr=df.S_central-df.S_right_neighbor
    factor=1/(1-np.exp2(-df.n.to_numpy(float)/2))
    df['fresh_response']=factor*(1-.4*(np.exp2(dl)+np.exp2(dr)))
    report[run]={'rows':len(df),'trajectories':df.trajectory_id.nunique(),
                 'max_response_discrepancy':float(np.max(abs(df.fresh_response-df.chi_relative))),
                 'boundary_increments_valid':bool(dl.isin([-1,0,1]).all() and dr.isin([-1,0,1]).all())}
    stored=pd.read_csv(CP/f'analysis/{run}/fixed_spectrum_size_slopes.csv')
    for (protocol,n),g in df.groupby(['protocol','n']):
        keys=['tau','S_central','p_measure']
        counts=g.groupby(keys).size().rename('count').reset_index()
        good=counts[counts['count']>=10].copy()
        levels=good.groupby(['tau','S_central']).p_measure.transform('nunique')
        eligible=good.loc[levels>=3,keys]
        s=g.merge(eligible,on=keys,how='inner')
        s['x']=(s.p_measure-.26)/.02
        groups=s.groupby(['tau','S_central'])
        x=s.x-groups.x.transform('mean'); y=s.fresh_response-groups.fresh_response.transform('mean')
        beta=float(x.dot(y)/x.dot(x))
        st=stored[(stored.protocol==protocol)&(stored.n==n)&(stored.outcome=='chi_relative')].iloc[0]
        slope_rows.append(dict(run=run,protocol=protocol,n=int(n),beta_recomputed=beta,beta_stored=st.beta,
                         absolute_error=abs(beta-st.beta),rows=len(s),stored_rows=int(st['rows'])))
pd.DataFrame(slope_rows).to_csv(OUT/'raw_row_slope_reconstruction.csv',index=False)
report['slope_max_error']=float(max(r['absolute_error'] for r in slope_rows))
# 2. Exponential fit residuals using the full source bootstrap covariance.
df=pd.read_csv(CP/'analysis/intervention/fixed_spectrum_distance_decay.csv')
f=json.loads((CP/'analysis/intervention/fixed_spectrum_distance_decay_fit.json').read_text())
b=np.load(CP/'analysis/intervention/intervention_bootstraps.npz')['distance']
x=df.distance.to_numpy(float);y=df.estimate.to_numpy(float)
yfit=-f['amplitude']*np.exp(-x/f['decay_length'])
se=b.std(axis=0,ddof=1);cov=np.cov(b,rowvar=False)
r=pd.DataFrame({'distance':x,'observed':y,'reported_fit':yfit,'ci_low':df.ci_low,'ci_high':df.ci_high,
                'bootstrap_se':se,'residual_over_marginal_se':(y-yfit)/se})
r['fit_outside_pointwise_interval']=(r.reported_fit<r.ci_low)|(r.reported_fit>r.ci_high)
r.to_csv(OUT/'distance_fit_residuals.csv',index=False)
L=cholesky(cov,lower=True)
def res(p):return solve_triangular(L, y+p[0]*np.exp(-x/p[1]),lower=True)
gls=least_squares(res,[f['amplitude'],f['decay_length']],bounds=([0,.05],[1,100]),xtol=1e-12,ftol=1e-12,gtol=1e-12)
report['decay_diagnostic']={'reported_amplitude':f['amplitude'],'reported_xi':f['decay_length'],
       'outside_pointwise_intervals':int(r.fit_outside_pointwise_interval.sum()),
       'max_abs_marginal_z':float(abs(r.residual_over_marginal_se).max()),
       'gls_amplitude':float(gls.x[0]),'gls_xi':float(gls.x[1]),
       'gls_quadratic_residual':float(gls.fun@gls.fun),'nominal_residual_dof':4,
       'note':'Exploratory covariance-aware model diagnostic. Not an exact goodness-of-fit p-value; bootstrap covariance is estimated and tail cells are sparse.'}
# 3. Independent reconstruction of pooled paired effects, preserving source
# definition: filter by spectrum first, average sides per distance, then compare.
raw=pd.read_csv(CP/'data/measurement_location_intervention/paired_measurement_interventions.csv.gz')
pairrows=[]
for cond in [False,True]:
    s=raw[raw.delta_S_central==0] if cond else raw
    m=s.groupby(['n','p_measure','trajectory_id','distance']).delta_chi_relative.mean().reset_index()
    near=m[m.distance==0].set_index(['n','p_measure','trajectory_id']).delta_chi_relative
    far=m[m.distance>=m.n/4].groupby(['n','p_measure','trajectory_id']).delta_chi_relative.mean()
    joint=pd.concat({'near':near,'far':far},axis=1).dropna()
    joint['contrast']=joint.near-joint.far
    c=joint.groupby(level=['n','p_measure']).contrast.mean()
    report[f'paired_{cond}']={'trajectories':len(joint),'equal_cell_estimate':float(c.mean()),'negative_cells':int((c<0).sum()),'cells':len(c)}
    pairrows.extend(dict(conditional=cond,n=int(n),p=float(p),estimate=float(v)) for (n,p),v in c.items())
pd.DataFrame(pairrows).to_csv(OUT/'paired_reconstruction.csv',index=False)
# 4. A stricter diagnostic: fixed same-side pair, distance 0 vs n/4, with both
# members required to preserve spectrum. Average eligible sides per trajectory.
near=raw[raw.distance==0].set_index(['n','p_measure','trajectory_id','side'])
far=raw[raw.distance==raw.n/4].set_index(['n','p_measure','trajectory_id','side'])
j=near[['delta_S_central','delta_chi_relative']].join(far[['delta_S_central','delta_chi_relative']],lsuffix='_near',rsuffix='_far',how='inner')
j=j[(j.delta_S_central_near==0)&(j.delta_S_central_far==0)].copy()
j['contrast']=j.delta_chi_relative_near-j.delta_chi_relative_far
trajectory=j.groupby(level=['n','p_measure','trajectory_id']).contrast.mean()
c=trajectory.groupby(level=['n','p_measure']).mean()
report['strict_same_side_pair_sensitivity']={'eligible_side_pairs':len(j),'trajectories':len(trajectory),'equal_cell_estimate':float(c.mean()),'negative_cells':int((c<0).sum()),'cells':len(c),'note':'New post-hoc estimand; no bootstrap interval computed.'}
c.rename('contrast').reset_index().to_csv(OUT/'strict_pair_sensitivity.csv',index=False)
# 5. Separate the sample-selection issue from the physical distance effect:
# common side/pre-state set with unchanged spectrum at each displayed distance.
use=raw[raw.distance.isin([0,1,2,4,8,16])].copy()
idx=['n','p_measure','trajectory_id','side']
p=use.pivot(index=idx,columns='distance',values='delta_S_central')
ids=p.index[(p==0).all(axis=1)&p.notna().all(axis=1)]
s=use.set_index(idx).loc[ids].reset_index()
v=s.groupby(['n','p_measure','trajectory_id','distance']).delta_chi_relative.mean().reset_index()
cell=v.groupby(['n','p_measure','distance']).delta_chi_relative.mean()
fixed_curve=cell.groupby('distance').mean()
fixed_curve.rename('common_stratum_estimate').reset_index().to_csv(OUT/'common_stratum_distance_sensitivity.csv',index=False)
report['common_stratum_distance_sensitivity']={'side_prestate_count':len(ids),'trajectory_count':v.trajectory_id.nunique(),'note':'New post-hoc common-eligibility curve. Not the frozen plotted estimand; no intervals computed.'}
# 6. Reconstruct the archived 1/n coefficients from stored size-level estimates.
fit_rows=[]
for run in ['primary','replication']:
    st=pd.read_csv(CP/f'analysis/{run}/fixed_spectrum_size_slopes.csv')
    saved=pd.read_csv(CP/f'analysis/{run}/thermodynamic_limit_fits.csv')
    for protocol,g in st[st.outcome=='chi_relative'].groupby('protocol'):
        x=1/g.n.to_numpy(float);y=g.beta.to_numpy(float);se=(g.ci_high-g.ci_low).to_numpy(float)/3.92
        X=np.column_stack([np.ones(len(g)),x]);w=1/se**2
        co=np.linalg.solve(X.T@(w[:,None]*X),X.T@(w*y))
        pred=X@co;z=(y-pred)/se
        fit_rows.append(dict(run=run,protocol=protocol,beta_infinity=co[0],a_over_n=co[1],diagonal_quadratic_residual=float(z@z),nominal_dof=2))
pd.DataFrame(fit_rows).to_csv(OUT/'size_fit_diagnostics.csv',index=False)
(OUT/'summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2));print('\nFIT RESIDUALS\n',r.to_string(index=False));print('\nSIZE FITS\n',pd.DataFrame(fit_rows).to_string(index=False));print('\nCOMMON STRATUM\n',fixed_curve.to_string())
