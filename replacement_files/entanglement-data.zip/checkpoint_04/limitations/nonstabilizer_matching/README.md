# Generic non-stabilizer physical matching

Nearest-neighbor matching of generic physical states was attempted with the predeclared calipers. Common support was sparse and model-dependent, especially for extreme monitoring rates. These files are retained for transparency and are not used as positive evidence. The clean physical-reachability result instead uses stabilizer states, for which fixed central Schmidt rank fixes the complete central spectrum exactly.
